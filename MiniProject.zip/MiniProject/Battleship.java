import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;




public class Logic extends JFrame {
	
	private static JPanel fieldPanel; 
	private static String FRAME_TITLE; 
	private static int HEIGHT, WIDTH; 
	private static int NUM_SHIPS; 
	private static int GRID_SIZE; 
	private static String P1_NAME; 
	private static String P2_NAME;
	private static boolean started;
	
	private JMenu fileMenu, helpMenu; 
	private ArrayList<Ship> shipsArrayList = new ArrayList<Ship>(); 
	private ArrayList<JButton> positionsArrayList = new ArrayList<JButton>();
	private static String RULES = "INSERT RULES"; 
	
	public static void main(String[] args) {
		
		JFrame f1 = new JFrame("Welcome to Battleship!"); 
		
		JPanel p1 = new JPanel(new BorderLayout()); 
		JLabel rules = new JLabel(RULES); 
		JButton startButton = new JButton("Start Game");
		startButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				f1.dispose(); 
				createPlayerPrompt();
			}
		});
		
		p1.add(rules, BorderLayout.NORTH); 
		p1.add(startButton, BorderLayout.SOUTH);
		f1.add(p1);
		
		f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		f1.setLocationRelativeTo(null);
		f1.setVisible(true); 
		f1.pack();
		
	}
	
	/*
	** Default Constructor 
	*/ 
	public Logic(){
		initalPrompt();
	}
	
	
	public class Listen implements ActionListener {
		public void actionPerformed(ActionEvent ae) {
			
		}
	}

	public static void createPlayerPrompt() {
		JFrame frame = new JFrame("Player Names"); 
		JPanel panel = new JPanel(new BorderLayout());
		JPanel center = new JPanel(new GridLayout(2,2)); 
		
		JLabel inst = new JLabel("Instructions: Please enter player names in the space "
			+  "provided below:");
		JLabel p1Name = new JLabel("Player 1: "); 
		p1Name.setHorizontalAlignment(JLabel.RIGHT);
		JLabel p2Name = new JLabel("Player 2: ");
		p2Name.setHorizontalAlignment(JLabel.RIGHT);
		
		JTextField p1Text = new JTextField(10); 
		JTextField p2Text = new JTextField(10); 
		
		JButton submitButton = new JButton("Submit & Start Game"); 
		submitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				String txt1 = p1Text.getText(); 
				String txt2 = p2Text.getText(); 
				
				if (txt1 == null || txt2 == null) {
					if (txt1 == null) {
						JOptionPane jop = new JOptionPane(); 
						jop.showMessageDialog(null,"Please provide a name for player 1"); 
					}
					if (txt2 == null) {
						JOptionPane jop = new JOptionPane(); 
						jop.showMessageDialog(null,"Please provide a name for player 2");
					}
				}
				
				if (txt1 != null && txt2 != null) {
					P1_NAME = txt1; 
					P2_NAME = txt2; 
					
					frame.dispose(); 
					
					// create the battleship
					//new Battleship("Battleship",400,400,5,5);
					
				}
			}
		});
		
		panel.add(inst, BorderLayout.NORTH);
		
		center.add(p1Name); 
		center.add(p1Text); 
		center.add(p2Name); 
		center.add(p2Text);
		
		panel.add(center, BorderLayout.CENTER);
		
		panel.add(submitButton, BorderLayout.SOUTH);
		
		frame.add(panel); 
		frame.setLocationRelativeTo(null); 
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
		frame.setVisible(true); 
		frame.pack();
		
		
	}
	
	public void choseSpots() {

		JFrame f1 = new JFrame("Player 1 - Board Setup"); 
		JPanel p1 = new JPanel(new BorderLayout()); 
		
		JLabel topLabel = new JLabel("Player 1, please choose your ships position"); 
		
		JLabel ship1Label = new JLabel("Ship 1: "); 
		JLabel ship2Label = new JLabel("Ship 2: "); 
		JLabel ship3Label = new JLabel("Ship 3: "); 
		JLabel ship4Label = new JLabel("Ship 4: "); 
		JLabel ship5Label = new JLabel("Ship 5: "); 
		
		JTextArea ship1PosX = ship1PosY = 
				ship2PosX = ship2PosY = 
				ship3PosX = ship3PosY = 
				ship4PosX = ship4PosY =
				ship5PosX = ship5PosY = new JTextArea(2);
				
		JPanel options = new JPanel(new GridLayout(5,3));
		
		options.add(ship1Label); 
		options.add(ship1PosX); 
		options.add(ship1PosY);  
		
		options.add(ship2Label); 
		options.add(ship2PosX); 
		options.add(ship2PosY);  
		
		options.add(ship3Label); 
		options.add(ship3PosX); 
		options.add(ship3PosY);  
		
		options.add(ship3Label); 
		options.add(ship3PosX); 
		options.add(ship3PosY);  
		
		options.add(ship4Label); 
		options.add(ship4PosX); 
		options.add(ship4PosY);  
		
		options.add(ship5Label); 
		options.add(ship5PosX); 
		options.add(ship5PosY);  
		
		JButton placeShipsButton = new JButton("Place Ships"); 
		placeShipsButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				/*
				** INSERT CODE TO EXECUTE ONCE PLAYER HAS FINISHED CHOOSING POSITIONS 
				**
				** MUST CHECK CONTENT OF BOXES TO MAKE THE VALUES ENTERED ARE VALID INTEGERS 
				*/ 
				
			}
		});
		
		p1.add(topLabel, BorderLayout.NORTH); 
		p1.add(options, BorderLayout.CENTER); 
		p1.add(placeShipsButton, BorderLayout.SOUTH); 
		
	}
	
	
}







