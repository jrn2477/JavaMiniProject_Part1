import java.util.*;
import java.awt.*;
import javax.swing.*;

public class GameBoard  {

	private ArrayList<Ship> shipsArrayList = new ArrayList<Ship>(); 
	private ArrayList<JButton> positionsArrayList = new ArrayList<JButton>();
	private Font verdana = new Font("Verdana", Font.BOLD, 22);
	private boolean started; 
	private boolean newGame; 
	private static String FRAME_TITLE; 
	private static int HEIGHT, WIDTH;
	
	public GameBoard(Boolean _started, boolean _newGame) {
		this.started = _started; 
		this.newGame = _newGame; 
	}
	
	/*
	** Method to create the Player Grid 
	*/ 
	public void createGrid(int size, String name) {
		String playerName = name; 
		int grid_size = size; 
		
		JFrame frame = new JFrame(playerName + "'s Turn");
		JLabel titleText = new JLabel(playerName + "'s Turn"); 

		JPanel fieldPanel = new JPanel(new GridLayout(GRID_SIZE,GRID_SIZE,0,0)); 		
		
		int count = 1; 
		
		if (!started) {
			for (int a = 0; a < grid_size; a++) {
				for (int b = 0; b < grid_size; b++) {
					String btnName = Integer.toString(count);
					JButton tempBtn = new JButton(btnName); 
					tempBtn.addActionListener(ls);
					tempBtn.setActionCommand(btnName); 
					tempBtn.setContentAreaFilled(true);
					tempBtn.setText(null);
					tempBtn.setBackground(Color.BLUE);
					tempBtn.setOpaque(true);
					positionsArrayList.add(tempBtn); 
					fieldPanel.add(tempBtn); 
					count++;
				}
			}
		}
		
		/*
		** TODO - ADD CODE TO GENERATE BUTTONS ONCE POSITIONS HAVE BEEN SET 
		*/ 
		
		
		frame.add(fieldPanel); 
		frame.setSize(HEIGHT,WIDTH);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		frame.pack();
		frame.setVisible(true); 
		frame.setLocationRelativeTo(null); 
		
	}
	
	public void checkPosition(Ship s) {
		int x = s.getX(); 
		int y = s.getY(); 
		
		
	}
	public class Listener implements ActionListener {
		public void actionPerformed(ActionEvent ae) {
			String src = ae.getActionCommand(); 
			int value = Integer.parseInt(src);
			int x; 
			int y; 
			
			
			switch (value) {
				case 1: // (1,1) 
					x = 1;
					y = 1;
					break;
				case 2: // (1,2)
					x = 1;
					y = 2;
					break;
				case 3: // (1,3)
					x = 1;
					y = 3;
					break; 
				case 4: // (1,4)
					x = 1;
					y = 4;
					break; 
				case 5: // (1,5) 
					x = 1;
					y = 5;
					break;
				case 6: // (2,1)
					x = 2;
					y = 1;
					break; 
				case 7: // (2,2)
					x = 2;
					y = 2;
					break;
				case 8: // (2,3)
					x = 2;
					y = 3;
					break;
				case 9: // (2,4)
					x = 2;
					y = 4;
					break;
				case 10: // (2,5)
					x = 2;
					y = 5;
					break;
				case 11: // (3,1)
					x = 3;
					y = 1;
					break;
				case 12: // (3,2)
					x = 3;
					y = 2;
					break;
				case 13: // (3,3)
					x = 3;
					y = 3;
					break;
				case 14: // (3,4)
					x = 3;
					y = 4;
					break;
				case 15: // (3,5)
					x = 3;
					y = 5;
					break;
				case 16: // (4,1)
					x = 4;
					y = 1;
					break;
				case 17: // (4,2)
					x = 4;
					y = 2;
					break; 
				case 18: // (4,3)
					x = 4;
					y = 3;
					break;
				case 19: // (4,4)
					x = 4;
					y = 4;
					break;
				case 20: // (4,5)
					x = 4;
					y = 5;
					break;
				case 21: // (5,1)
					x = 5;
					y = 1;
					break;
				case 22: // (5,2)
					x = 5;
					y = 2;
					break;
				case 23: // (5,3)
					x = 5;
					y = 3;
					break;
				case 24: // (5,4)
					x = 5;
					y = 4;
					break;
				case 25: // (5,5)
					x = 5;
					y = 5;
					break;
				default:
					System.out.println("Invalid Action Command");
					break;
			}
		}
	}
	
}