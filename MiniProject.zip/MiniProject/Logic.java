import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;




public class Logic extends JFrame {
	
 	private static boolean running = false;
	private static int NUM_SHIPS; 
	private static String P1_NAME; 
	private static String P2_NAME;
	private static int NUM_PLAYERS = 2; 
	private static int playerCount = 0; 
	private static int turn = 0; 
	private static Player p1; 
	private static int p1Hits = 0; 
	private static int p2Hits = 0; 
	private static Player p2; 
	private static Gameboard p1Gameboard; 
	private static Gameboard p2Gameboard; 
	
	// TODO -- private JMenu fileMenu, helpMenu; 
	private static String RULES = "INSERT RULES"; 
	
	public static void main(String[] args) {
		
		JFrame f1 = new JFrame("Welcome to Battleship!"); 
		
		JPanel p1 = new JPanel(new BorderLayout()); 
		JLabel rules = new JLabel(RULES); 
		JButton startButton = new JButton("Start Game");
		startButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				f1.dispose(); 
				createPlayerPrompt();
			}
		});
		
		p1.add(rules, BorderLayout.NORTH); 
		p1.add(startButton, BorderLayout.SOUTH);
		f1.add(p1);
		
		f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		f1.setLocationRelativeTo(null);
		f1.setVisible(true); 
		f1.pack();
		
	}
	
	public Logic(){		
		createPlayerPrompt();
	}
	
//	public void createGrid() {
//		JFrame frame; 
//		JPanel fieldPanel = new JPanel(new GridLayout(GRID_SIZE,GRID_SIZE,0,0)); 		
//		
//		int count = 1; 
//		
//		/*
//		** Positions have not been set - setup blank board
//		*/ 
//		if (!started) {
//			for (int a = 0; a < GRID_SIZE; a++) {
//				for (int b = 0; b < GRID_SIZE; b++) {
//					String btnName = Integer.toString(count);
//					JButton tempBtn = new JButton(btnName); 
//					tempBtn.addActionListener(ls);
//					tempBtn.setActionCommand(btnName); 
//					tempBtn.setContentAreaFilled(true);
//					tempBtn.setText(null);
//					tempBtn.setBackground(Color.BLUE);
//					tempBtn.setOpaque(true);
//					positionsArrayList.add(tempBtn); 
//					fieldPanel.add(tempBtn); 
//					count++;
//				}
//			}
//		}
//		
//		/*
//		** TODO - ADD CODE TO GENERATE BUTTONS ONCE POSITIONS HAVE BEEN SET 
//		*/ 
//		
//		
//		frame = new JFrame(); 
//		frame.add(fieldPanel); 
//		frame.setSize(HEIGHT,WIDTH);
//		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
//		frame.pack();
//		frame.setVisible(true); 
//		frame.setLocationRelativeTo(null); 
//		
//	}

	public static void createPlayerPrompt() {
		JFrame frame = new JFrame("Player Names"); 
		JPanel panel = new JPanel(new BorderLayout(10,10));
		JPanel center = new JPanel(new GridLayout(2,2)); 
		
		JLabel inst = new JLabel("Instructions: Please enter player names in the space "
			+  "provided below:");
		JLabel p1Name = new JLabel("Player 1: "); 
		p1Name.setHorizontalAlignment(JLabel.RIGHT);
		JLabel p2Name = new JLabel("Player 2: ");
		p2Name.setHorizontalAlignment(JLabel.RIGHT);
		
		JTextField p1Text = new JTextField(10); 
		JTextField p2Text = new JTextField(10); 
		
		JButton submitButton = new JButton("Submit & Start Game"); 
		submitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				String txt1 = p1Text.getText(); 
				String txt2 = p2Text.getText(); 
				
				if (txt1 == null || txt2 == null) {
					if (txt1 == null) {
						JOptionPane jop = new JOptionPane(); 
						jop.showMessageDialog(null,"Please provide a name for player 1"); 
					}
					if (txt2 == null) {
						JOptionPane jop = new JOptionPane(); 
						jop.showMessageDialog(null,"Please provide a name for player 2");
					}
				}
				
				if (txt1 != null && txt2 != null) {
					P1_NAME = txt1; 
					P2_NAME = txt2; 
					
					frame.dispose(); 
					
					p1 = new Player(P1_NAME,1); 
					p2 = new Player(P2_NAME, 2); 
					
					frame.dispose();
					selectSpots(); 
				}
			}
		});
		
		panel.add(inst, BorderLayout.NORTH);
		
		center.add(p1Name); 
		center.add(p1Text); 
		center.add(p2Name); 
		center.add(p2Text);
		
		panel.add(center, BorderLayout.CENTER);
		
		panel.add(submitButton, BorderLayout.SOUTH);
		
		frame.add(panel); 
		frame.setLocationRelativeTo(null); 
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
		frame.setVisible(true); 
		frame.pack();
		
		
	}
	
	public static void selectSpots() {
		playerCount++; 
		String name = null; 
		
		if (playerCount == 1) {
			shipChoser(p1); 
		}
		if (playerCount == 2) {
			shipChoser(p1); 
		}
		
		if (playerCount >= 3) {
			
			new Grid(p1, p2);

			}
		}
	}
	
	
	
	
	public static void shipChoser(Player player) {
		String name = player.getPlayerName(); 
		JFrame f1 = new JFrame(name + " (Player " + 
			Integer.toString(playerCount) + ")  - Board Setup"); 
		JPanel p1 = new JPanel(new BorderLayout(10,10)); 
		
		JLabel topLabel = new JLabel(name + " (Player " + 
			Integer.toString(playerCount) + "), please choose your ships' positions"); 
		
		JLabel ship1Label = new JLabel("Ship 1: "); 
		JLabel ship2Label = new JLabel("Ship 2: "); 
		JLabel ship3Label = new JLabel("Ship 3: "); 
		JLabel ship4Label = new JLabel("Ship 4: "); 
		JLabel ship5Label = new JLabel("Ship 5: "); 
		
		JTextField ship1PosX = new JTextField(2);
		JTextField ship1PosY = new JTextField(2);
		JTextField ship2PosX = new JTextField(2);
		JTextField ship2PosY = new JTextField(2);
		JTextField ship3PosX = new JTextField(2);
		JTextField ship3PosY = new JTextField(2);
		JTextField ship4PosX = new JTextField(2);
		JTextField ship4PosY = new JTextField(2);
		JTextField ship5PosX = new JTextField(2);
		JTextField ship5PosY = new JTextField(2);
				
		JPanel options = new JPanel(new GridLayout(5,3));
		
		options.add(ship1Label); 
		options.add(ship1PosX); 
		options.add(ship1PosY);  
		
		options.add(ship2Label); 
		options.add(ship2PosX); 
		options.add(ship2PosY);  
		
		options.add(ship3Label); 
		options.add(ship3PosX); 
		options.add(ship3PosY);  
		
		options.add(ship3Label); 
		options.add(ship3PosX); 
		options.add(ship3PosY);  
		
		options.add(ship4Label); 
		options.add(ship4PosX); 
		options.add(ship4PosY);  
		
		options.add(ship5Label); 
		options.add(ship5PosX); 
		options.add(ship5PosY);  
		
		JButton placeShipsButton = new JButton("Place Ships"); 
		placeShipsButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				
				String x1 = ship1PosX.getText(); 
				String y1 = ship1PosY.getText(); 
				
				String x2 = ship2PosX.getText(); 
				String y2 = ship2PosY.getText(); 
				
				String x3 = ship3PosX.getText(); 
				String y3 = ship3PosY.getText(); 
				
				String x4 = ship4PosX.getText(); 
				String y4 = ship4PosY.getText(); 
				
				String x5 = ship5PosX.getText(); 
				String y5 = ship5PosY.getText(); 
				
				try {
					
					// Parse and Test Inputs 
					// if invalid input is found
					// an error message will be displayed 
					int _x1 = Integer.parseInt(x1); 
					boolean sx1 = testInput(_x1);
					int _y1 = Integer.parseInt(y1); 
					boolean sy1 = testInput(_y1);
					
					int _x2 = Integer.parseInt(x2); 
					boolean sx2	= testInput(_x2);
					int _y2 = Integer.parseInt(y2); 
					boolean sy2	= testInput(_y2);
					
					int _x3 = Integer.parseInt(x3); 
					boolean sx3	= testInput(_x2);
					int _y3 = Integer.parseInt(y3); 
					boolean sy3	= testInput(_y3);
					
					int _x4 = Integer.parseInt(x4); 
					boolean sx4	= testInput(_x4);
					int _y4 = Integer.parseInt(y4); 
					boolean sy4	= testInput(_y4);
					
					int _x5 = Integer.parseInt(x5); 
					boolean sx5	=testInput(_x5);
					int _y5 = Integer.parseInt(y5); 
					boolean sy5	= testInput(_y5);
					
					
					if (sx1 && sy1 && sx2 && sy2 && sx3 && sy3 && sx4 && sy4 && sx5 && sy5) {
						try {
							// All values entered are integer values 
							// create the ships 
							Ship s1 = new Ship(_x1, _y1); 
							Ship s2 = new Ship(_x2, _y2); 
							Ship s3 = new Ship(_x3, _y3);
							Ship s4 = new Ship(_x4, _y4); 
							Ship s5 = new Ship(_x5, _y5);
							
							player.addShip(s1); 
							player.addShip(s2); 
							player.addShip(s3); 
							player.addShip(s4); 
							player.addShip(s5);
						} catch (Exception e) {
							System.out.println("Error creating/adding the ships");
						}
					}
					
					
				} catch (Exception e) {
					// notify user of invalid inputs 
					displayMessage("All values must be integers values between 1 - 8"); 
					
					// reset textfields 
					ship1PosX.setText(null); 
					ship1PosY.setText(null); 
					ship2PosX.setText(null); 
					ship2PosY.setText(null); 
					ship3PosX.setText(null); 
					ship3PosY.setText(null); 
					ship4PosX.setText(null); 
					ship4PosY.setText(null); 
					ship5PosX.setText(null); 
					ship5PosY.setText(null); 
					return; 
				}
				
				f1.dispose();
				// recall select spots 
				selectSpots();
			}
		});
		
		p1.add(topLabel, BorderLayout.NORTH); 
		p1.add(options, BorderLayout.CENTER); 
		p1.add(placeShipsButton, BorderLayout.SOUTH); 
		f1.add(p1); 
		f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
		f1.setLocationRelativeTo(null); 
		f1.setVisible(true); 
		f1.pack();
	}
	
	public static void displayMessage(String msg) {
		JOptionPane jop = new JOptionPane(); 
		jop.showMessageDialog(null, msg); 
		
	}
	
	
	
	
	/*
	** Method to test input coordinates 
	** @returns TRUE if input is valid 
	** @returns FALSE if input is invalid 
	** @param input 
	*/ 
	public static boolean testInput(int input) {
		if (input > 8 || input < 1) {
			displayMessage("All values must be integers values between 1 - 8");
			return true; 
		}
		return false; 
	}
	
	
	
	/*
	** Method to get turn 
	** @return 1 if Player 1 turn 
	** @return 2 if Player 2 turn 
	** @return -1 if game not started 
	*/ 
	public static int getTurn() {
		int i = turn % 2; 
		if (i == 0) {
			//is an even number
			return 2;  
		} 
		else if (i == 1) {
			//is an odd number 
			return 1;
		} else {
			return -1;
		}
	}
}







