import javax.swing.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

public class Grid extends JFrame {
	
	ArrayList<Ship> p1Ships, p2Ships;
	private JLabel btmLabel, topLabel, eastLabel, westLabel;
	private JPanel gridPanel, mainPanel, eastPanel, westPanel, northPanel;
	private String player1msg = "Turn: \nPlayer 1";
	private String player2msg = "Turn: \nPlayer 2";
	private JTextArea gameLog; 
	private int p1ShipsSunk;
	private int p2ShipsSunk; 
	private int round; 
	private Thread t1; 
	private boolean running; 
	private Font verdana = new Font("Verdana", Font.BOLD, 22);
	private static int windowHieght, windowWidth;
	private static String windowTitle; 
	private static final int GRID_SIZE = 5; 
	private static Player p1, p2; 
	
	
	private ArrayList<SButton> btnList = new ArrayList<SButton>();
	private SButton btn1, btn2, btn3, btn4, btn5, 
	btn6,  btn7,  btn8,  btn9,  btn10, 
	btn11, btn12, btn13, btn14, btn15,
	btn16, btn17, btn18, btn19, btn20, 
	btn21, btn22, btn23, btn24, btn25; 
	
	/*
	** Default Constructor 
	** @param a - player commanding board 
	** @param b - player being attacked 
	*/
	public Grid(Player a, Player b) {
			running = true;
			round = 0; 
			p1ShipsSunk = 0; 
			p2ShipsSunk = 0; 
			p1 = a; 
			p2 = b; 
			
			// Setup Buttons 
			btn1 = new SButton(1,1); 
			btn1.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 1,1");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 1,1");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn1);
			gridPanel.add(btn1);
			
			btn2 = new SButton(1,2); 
			btn2.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 1,2");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 1,2");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn2);
			gridPanel.add(btn2);
			
			btn3 = new SButton(1,3); 
			btn3.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 1,3");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 1,3");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn3);
			gridPanel.add(btn3);

			btn4 = new SButton(1,4); 
			btn4.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 1,4");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 1,4");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn4);
			gridPanel.add(btn4);

			btn5 = new SButton(1,5);
			btn5.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 1,5");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 1,5");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});  
			btnList.add(btn5);
			gridPanel.add(btn5);

			btn6 = new SButton(2,1); 
			btn6.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 2,1");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 2,1");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn6);
			gridPanel.add(btn6);

			btn7 = new SButton(2,2); 
			btn7.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 2,2");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 2,2");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn7);
			gridPanel.add(btn7);

			btn8 = new SButton(2,3); 
			btn8.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 2,3");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 2,3");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn8);
			gridPanel.add(btn8);

			btn9 = new SButton(2,4); 
			btn9.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 2,4");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 2,4");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn9);
			gridPanel.add(btn9);

			btn10 = new SButton(2,5); 
			btn10.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 2,5");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 2,5");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn10);
			gridPanel.add(btn10);

			btn11 = new SButton(3,1); 
			btn11.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 3,1");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 3,1");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn11);
			gridPanel.add(btn11);

			btn12 = new SButton(3,2); 
			btn12.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 3,2");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 3,2");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn12);
			gridPanel.add(btn12);

			btn13 = new SButton(3,3); 
			btn13.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 3,3");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 3,3");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn13);
			gridPanel.add(btn13);

			btn14 = new SButton(3,4); 
			btn14.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 3,4");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 3,4");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn14);
			gridPanel.add(btn14);

			btn15 = new SButton(3,5); 
			btn15.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 3,5");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 3,5");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn15);
			gridPanel.add(btn15);

			btn16 = new SButton(4,1); 
			btn16.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 4,1");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 4,1");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn16);
			gridPanel.add(btn16);

			btn17 = new SButton(4,2); 
			btn17.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 4,2");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 4,2");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn17);
			gridPanel.add(btn17);

			btn18 = new SButton(4,3); 
			btn18.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 4,3");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 4,3");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn18);
			gridPanel.add(btn18);

			btn19 = new SButton(4,4); 
			btn19.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 4,4");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 4,4");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn19);
			gridPanel.add(btn19);

			btn20 = new SButton(4,5); 
			btn20.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 4,5");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 4,5");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn20);
			gridPanel.add(btn20);

			btn21 = new SButton(5,1); 
			btn21.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 5,1");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 5,1");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn21);
			gridPanel.add(btn21);

			btn22 = new SButton(5,2); 
			btn22.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 5,2");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 5,2");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn22);
			gridPanel.add(btn22);

			btn23 = new SButton(5,3); 
			btn23.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 5,3");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 5,3");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn23);
			gridPanel.add(btn23);

			btn24 = new SButton(5,4); 
			btn24.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 5,4");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 5,4");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn24);
			gridPanel.add(btn24);

			btn25 = new SButton(5,5); 
			btn25.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					// Whose turn is it?
					// 1 = Player 1 
					// 2 = Player 2 
					int p = getTurn();
					
					// it is ______'s turn 
					// launch attack 
					boolean hit = checkAndMarkSpace(p);
					
					// was attack a hit or miss?
					if (hit) {
						// it was a hit 
						updateDisplay("Player " + p + " hit and sunk a ship at 5,5");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
						if (p == 1) {
							p1ShipsSunk++;
						} if (p ==2) {
							p2ShipsSunk++;
						}
					} else {
						// it was a miss
						updateDisplay("Player " + p + " failed to reach target at 5,5");
						gridPanel = reDrawGrid(btnList);
						 //this.repaint();
						round++;
					}
					
					// check to see if game is over 
					if (p1ShipsSunk > 4 || p2ShipsSunk > 4) {
						running = false; 
						JFrame f = new JFrame("Game Over!");
						JPanel jp = new JPanel(new FlowLayout());
						JLabel l = new JLabel("Player " + p + " won the game.");
						
						jp.add(l);
						f.add(jp);
						f.setLocationRelativeTo(null);
						f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						f.setVisible(true);
						f.pack();
					}
				}
			});
			btnList.add(btn25);
			gridPanel.add(btn25);
			
			// launch game 
			setMarkedSpaces(p1, p2);
			init();

	}
	
	public void init(){
		mainPanel = new JPanel(new BorderLayout());
		gridPanel = new JPanel(new GridLayout(5,5));
		westPanel = new JPanel(new GridLayout(1,1));
		eastPanel = new JPanel(new GridLayout(2,1));
		northPanel = new JPanel(new FlowLayout());
		
		// setup north panel
		topLabel = new JLabel("Battleship");
		topLabel.setFont(verdana);
		northPanel.add(topLabel);
		
		// Setup west panel
		if ((round % 2) == 0) {
			westLabel = new JLabel(player1msg);
		}
		if ((round %2) != 0) {
			westLabel = new JLabel(player2msg);
		}
		westLabel.add(westLabel);
		
		// setup east panel 
		eastLabel = new JLabel("Game Log: ");
		gameLog = new JTextArea(10,25);
		eastPanel.add(eastLabel);
		eastPanel.add(gameLog);
		
		//setup grid 
		gridPanel = reDrawGrid(btnList);
		
	}
	
	public void updateDisplay(String appendmsg){
		gameLog.append("\n" + appendmsg);
		if ((round % 2) == 0) {
			westLabel.setText(player1msg);
		}
		if ((round %2) != 0) {
			westLabel.setText(player2msg);
		}
	}
	
	
	/*
	** Method to draw the grid 
	*/ 
	public JPanel reDrawGrid(ArrayList<SButton> al){
		JPanel panel = new JPanel(new GridLayout(5,5));
		ArrayList<SButton> btnList = al;
		int turn = getTurn(); 
		// Player 1 = 1 
		// Player 2 = 2
		int end = btnList.size();
		
		if (turn == 1) {
			for (int a = 0; a < end; a++) {
				boolean p1HitStatus = btnList.get(a).getP1HitStatus();
				panel.add(btnList.get(a)); 
				if (p1HitStatus == true) {
					//spot has been hit, disable 
					btnList.get(a).setEnabled(false);
				}
				else {
					//spot has not been hit, enable 
					btnList.get(a).setEnabled(true);
				}
			}
			return panel;
		}
		else if (turn == 2) {
			for (int a = 0; a < end; a++) {
				boolean p2HitStatus = btnList.get(a).getP2HitStatus();
				panel.add(btnList.get(a)); 
				if (p2HitStatus == true) {
					//spot has been hit, disable 
					btnList.get(a).setEnabled(false);
				}
				else {
					//spot has not been hit, enable 
					btnList.get(a).setEnabled(true);
				}
			}
			return panel;
		}
		else {
			return panel;
		}
		
	}
	
	
	public int getTurn(){
		int i = round % 2; 
		if (i == 0) {
			// Even Number - Player 2
			return 2; 
		} else {
			// Odd Number - Player 1 
			return 1;
		}
	}
	
	public boolean checkAndMarkSpace(int num){
		// 1 = Player 1 
		// 2 = Player 2 
		int selection = num;
		// CODE IF PLAYER 1 
		if (selection == 1) {
			int length = btnList.size();
			for (int i = 0; i < length; i++) {
				boolean test = btnList.get(i).getP1HitStatus();
				if (!test) {
					btnList.get(i).p1Hit();
					return true;
				}
				else {
					JOptionPane JOP = new JOptionPane();
					JOP.showMessageDialog(null, "Oops... that space has already been clicked" +
						"\nPlease select another");
					btnList.get(i).p1Hit();
					return false;
				}
			}
		}
		
		// CODE IF PLAYER 2 
		else if (selection == 2) {
			int length = btnList.size();
			for (int i = 0; i < length; i++) {
				boolean test = btnList.get(i).getP2HitStatus();
				if (!test) {
					btnList.get(i).p2Hit();
					return true;

				}
				else {
					JOptionPane JOP = new JOptionPane();
					JOP.showMessageDialog(null, "Oops... that space has already been clicked" +
						"\nPlease select another");
					btnList.get(i).p2Hit();
					return false;

				}
			}
			return false;
		} 
		else {
			JOptionPane JOP = new JOptionPane();
			JOP.showMessageDialog(null, "Oops... Something went wrong");
			}
			return false;
		}
		
	public void setMarkedSpaces(Player p1, Player p2) {
		for (int z = 0; z < p2.getShipList().size() ; z++) {
			//Ship ship = p1.getShipList().get(z);
			
			// set up markek spaces for player 1 
			int x = p2.getShipList().get(z).getX();
			int y = p2.getShipList().get(z).getY();
			
			for (int i = 0; i < btnList.size(); i++) {
				if	((btnList.get(z).getX() == x) && (btnList.get(z).getX() == y)) {
					btnList.get(i).setP1Marked();
				}
			}
			
			//set up marked positions for player 2
			for (int j = 0; j < btnList.size(); j++) {
				if	((btnList.get(z).getX() == x) && (btnList.get(z).getX() == y)) {
					btnList.get(z).setP2Marked();
				}
			}
		}
	}
	
	public void markSpace(int x, int y, int p) {
		int end = btnList.size();
		for (int i = 0; i < end; i++) {
			int checkX = btnList.get(i).getX();
			int checkY = btnList.get(i).getY();
			
			if (p == 1) {
				if (checkX == x && checkY == y) {
					btnList.get(i).setP1Marked();
				}
			}
			if (p == 2) {
				if (checkX == x && checkY == y) {
					btnList.get(i).setP2Marked();
				}
			}
			
		}
	}
}
