import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Gameboard extends JFrame implements Runnable{

	private ArrayList<Ship> p1shipsArrayList = new ArrayList<Ship>(); 
	private ArrayList<Ship> p2shipsArrayList = new ArrayList<Ship>(); 
	private ArrayList<JButton> positionsArrayList = new ArrayList<JButton>();
	private Font verdana = new Font("Verdana", Font.BOLD, 22);
	private boolean started; 
	private boolean newGame; 
	private static String FRAME_TITLE; 
	private static int HEIGHT, WIDTH;
	private static int GRID_SIZE = 5;
	private static Player attackingPlayer,defendingPlayer; 
	private Listener ls;
	private int hits = 0; 
	private static boolean turnOver; 
	JFrame FRAME;
	private Thread thread;

	public Gameboard(Player _attackingPlayer,Player _defendingPlayer) {
		started = false;
		turnOver = false;
		this.attackingPlayer = _attackingPlayer;
		this.defendingPlayer = _defendingPlayer; 
		ls = new Listener();  
	}
	
	public void run(){
		runGame();
	}
	
	
	public synchronized void start(){
		thread = new Thread(this);
		thread.start();
	}
	public synchronized void stop(){
		try {
			thread.join();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void runGame() {
		if (started == true) {
			if (hits == 5) {
				FRAME.dispose();
			} 
		}
		else {
			createGrid(attackingPlayer.getPlayerName());
		}
	}
	
	/*
	** Method to create the Player Grid 
	*/ 
	public void createGrid(String name) {
		started = true;
		String playerName = name; 
		int grid_size = GRID_SIZE; 
		
		FRAME = new JFrame(playerName + "'s Turn");
		JLabel titleText = new JLabel(playerName + "'s Turn"); 

		JPanel fieldPanel = new JPanel(new GridLayout(GRID_SIZE,GRID_SIZE,0,0)); 		
		
		int count = 1; 
		
		if (!started) {
			for (int a = 0; a < grid_size; a++) {
				for (int b = 0; b < grid_size; b++) {
					String btnName = Integer.toString(count);
					JButton tempBtn = new JButton(btnName); 
					tempBtn.addActionListener(ls);
					tempBtn.setActionCommand(btnName); 
					tempBtn.setContentAreaFilled(true);
					tempBtn.setText(null);
					tempBtn.setBackground(Color.BLUE);
					tempBtn.setOpaque(true);
					positionsArrayList.add(tempBtn); 
					fieldPanel.add(tempBtn); 
					count++;
				}
			}
		}
		
		FRAME.add(fieldPanel); 
		FRAME.setSize(HEIGHT,WIDTH);
		FRAME.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		FRAME.pack();
		FRAME.setVisible(true); 
		FRAME.setLocationRelativeTo(null); 
		
	}
	
	
	/*
	** Method to check if the position is one of the players ships 
	** @param Player p - the Player whose ship is being targeted 
	** @param Ship s - Ship object to compare to 
	** @return hit - boolean value; TRUE if hit & FALSE if miss 
	*/ 
	public boolean checkPosition(Player p, Ship s) {
		Player player = p; 
		ArrayList<Ship> tempShipList = p.getShipList(); 
		
		boolean hit = false; 
		
		int size = tempShipList.size();
		for (int i = 0; i < size; i++) {
			Ship testShip = tempShipList.get(i); 
			if (testShip.equals(s)) {
				hit = true; 
			}
		}
		return hit;
	}
	
	
	
	
	public class Listener implements ActionListener {
		public void actionPerformed(ActionEvent ae) {
			boolean hit = false;
			String src = ae.getActionCommand(); 
			int value = Integer.parseInt(src);
			int x = 0; 
			int y = 0;
			
			
			switch (value) {
				case 1: // (1,1) 
					x = 1;
					y = 1;
					break;
				case 2: // (1,2)
					x = 1;
					y = 2;
					break;
				case 3: // (1,3)
					x = 1;
					y = 3;
					break; 
				case 4: // (1,4)
					x = 1;
					y = 4;
					break; 
				case 5: // (1,5) 
					x = 1;
					y = 5;
					break;
				case 6: // (2,1)
					x = 2;
					y = 1;
					break; 
				case 7: // (2,2)
					x = 2;
					y = 2;
					break;
				case 8: // (2,3)
					x = 2;
					y = 3;
					break;
				case 9: // (2,4)
					x = 2;
					y = 4;
					break;
				case 10: // (2,5)
					x = 2;
					y = 5;
					break;
				case 11: // (3,1)
					x = 3;
					y = 1;
					break;
				case 12: // (3,2)
					x = 3;
					y = 2;
					break;
				case 13: // (3,3)
					x = 3;
					y = 3;
					break;
				case 14: // (3,4)
					x = 3;
					y = 4;
					break;
				case 15: // (3,5)
					x = 3;
					y = 5;
					break;
				case 16: // (4,1)
					x = 4;
					y = 1;
					break;
				case 17: // (4,2)
					x = 4;
					y = 2;
					break; 
				case 18: // (4,3)
					x = 4;
					y = 3;
					break;
				case 19: // (4,4)
					x = 4;
					y = 4;
					break;
				case 20: // (4,5)
					x = 4;
					y = 5;
					break;
				case 21: // (5,1)
					x = 5;
					y = 1;
					break;
				case 22: // (5,2)
					x = 5;
					y = 2;
					break;
				case 23: // (5,3)
					x = 5;
					y = 3;
					break;
				case 24: // (5,4)
					x = 5;
					y = 4;
					break;
				case 25: // (5,5)
					x = 5;
					y = 5;
					break;
				default:
					System.out.println("Invalid Action Command");
					break;
			}// end switch 
			
			if (x ==0 || y == 0) {
				System.out.println("Error locating ship"); 
			} else {
				// input is valid 
				// test ship location
				Ship tempShip = new Ship(x, y);
				hit = checkPosition(defendingPlayer, tempShip);
			}
			
			
			if (hit) {
				launchAttack(x, y,"Hit");
				hits++;
			}
			else {
				launchAttack(x, y,"Miss");

			}
			
			
		}
	}
	
	public void launchAttack(int x, int y, String str) {
		
		switch (x) {
			case 1:
				switch (y) {
					case 1:
						positionsArrayList.get(1).setEnabled(false);
						positionsArrayList.get(1).setText(str);
						break;
					case 2:
						positionsArrayList.get(2).setEnabled(false);
						positionsArrayList.get(2).setText(str);						
						break;
					case 3:
						positionsArrayList.get(3).setEnabled(false);
						positionsArrayList.get(3).setText(str);
						break;
					case 4:
						positionsArrayList.get(4).setEnabled(false);
						positionsArrayList.get(4).setText(str);
						break;
					case 5:
						positionsArrayList.get(5).setEnabled(false);
						positionsArrayList.get(5).setText(str);
						break;
					default:
						break;
				}
				break;
			case 2:
				switch (y) {
					case 1:
						positionsArrayList.get(6).setEnabled(false);
						positionsArrayList.get(6).setText(str);
						break;
					case 2:
						positionsArrayList.get(7).setEnabled(false);
						positionsArrayList.get(7).setText(str);
						break;
					case 3:
						positionsArrayList.get(8).setEnabled(false);
						positionsArrayList.get(8).setText(str);
						break;
					case 4:
						positionsArrayList.get(9).setEnabled(false);
						positionsArrayList.get(9).setText(str);
						break;
					case 5:
						positionsArrayList.get(10).setEnabled(false);
						positionsArrayList.get(10).setText(str);
						break;
					default:
						break;
				}
				break;
			case 3:
				switch (y) {
					case 1:
						positionsArrayList.get(11).setEnabled(false);
						positionsArrayList.get(11).setText(str);
						break;
					case 2:
						positionsArrayList.get(12).setEnabled(false);
						positionsArrayList.get(12).setText(str);
						break;
					case 3:
						positionsArrayList.get(13).setEnabled(false);
						positionsArrayList.get(13).setText(str);
						break;
					case 4:
						positionsArrayList.get(14).setEnabled(false);
						positionsArrayList.get(14).setText(str);
						break;
					case 5:
						positionsArrayList.get(15).setEnabled(false);
						positionsArrayList.get(15).setText(str);
						break;
					default:
						break;
				}
				break;
			case 4:
				switch (y) {
					case 1:
						positionsArrayList.get(16).setEnabled(false);
						positionsArrayList.get(16).setText(str);
						break;
					case 2:
						positionsArrayList.get(17).setEnabled(false);
						positionsArrayList.get(17).setText(str);
						break;
					case 3:
						positionsArrayList.get(18).setEnabled(false);
						positionsArrayList.get(18).setText(str);	
						break;
					case 4:
						positionsArrayList.get(19).setEnabled(false);
						positionsArrayList.get(19).setText(str);
						break;
					case 5:
						positionsArrayList.get(20).setEnabled(false);
						positionsArrayList.get(20).setText(str);
						break;
					default:
						break;
				}
				break;
			case 5:
				switch (y) {
					case 1:
						positionsArrayList.get(21).setEnabled(false);
						positionsArrayList.get(21).setText(str);
						break;
					case 2:
						positionsArrayList.get(22).setEnabled(false);
						positionsArrayList.get(22).setText(str);
						break;
					case 3:
						positionsArrayList.get(23).setEnabled(false);
						positionsArrayList.get(23).setText(str);
						break;
					case 4:
						positionsArrayList.get(24).setEnabled(false);
						positionsArrayList.get(24).setText(str);
						break;
					case 5:
						positionsArrayList.get(25).setEnabled(false);
						positionsArrayList.get(25).setText(str);
						break;
					default:
						break;
				}
				break;
			default:
				break;
		}
		turnOver = true;
	}
	public boolean turnOver(){
		return turnOver;
	}
	
	public void makeInvisible() {
		FRAME.setVisible(false);
		FRAME.setLocation(10000,10000);
	}
	
	public void makeVisible() {
		FRAME.setVisible(true);
		FRAME.setLocationRelativeTo(null);
	}
	
}