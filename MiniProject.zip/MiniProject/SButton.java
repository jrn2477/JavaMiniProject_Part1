import javax.swing.*;

public class SButton extends JButton {
		private boolean p1Hit, p2Hit;
		private boolean p1marked, p2marked;
		private int x; 
		private int y; 
		
		public SButton(int x, int y) {
			this.x = x; 
			this.y = y; 
			p1Hit = false; 
			p2Hit = false;
			p1marked = false;
			p2marked = false;
			this.setText("???");
			this.setEnabled(true);
		}
		
		
		public int getX(){
			return x; 
		}
		public int getY() {
			return y; 
		}
		public void setX(int i){
			x = i; 
		}
		public void setY(int i){
			y = i; 
		}
		public void p1Hit(){
			p1Hit = true;
		}
		public void p2Hit(){
			p2Hit = true;
		}
		public boolean getP1HitStatus(){
			return p1Hit;
		}
		public boolean getP2HitStatus(){
			return p2Hit;
		}
		
		/*
		** Method to mark this spot for player 1
		** @return void 
		*/ 
		public void setP1Marked(){
			p1marked = true;
		}
		
		/*
		** Method to mark this spot for player 1
		** @return void 
		*/ 
		public void setP2Marked(){
			p2marked = true;
		}
		
		/*
		** Method to see if player 1 marked this spot 
		** @returns true if player 1 marked this spot 
		*/ 
		public boolean p1Marked() {
			if (p1marked == true) {
				return true;
			} else {
				return false; 
			}
		}
		
		/*
		** Method to see if player 2 marked this spot 
		** @returns true if player 2 marked this spot 
		*/ 
		public boolean p2marked() {
			if (p2marked == true) {
				return true;
			} else {
				return false; 
			}
			
		}
}