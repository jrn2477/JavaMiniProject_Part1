import java.util.*;
import javax.swing.*;

public class Player  {

	private String PLAYER_NAME = null; 
	private ArrayList<Ship> shipsArrayList = new ArrayList<Ship>(); 
	private int playerPos;
	private boolean won; 
	
	public Player(String name, int p) {
		PLAYER_NAME = name; 
		playerPos = p; 
		won = false; 
		
	}

	public void setPlayerName(String s) {
		PLAYER_NAME = s; 
	}
	
	public String getPlayerName() {
		return PLAYER_NAME; 
	}
	
	public void winGame() {
		won = true;
		JOptionPane jop = new JOptionPane(); 
		jop.showMessageDialog(null, "Game Over \n\n" +getPlayerName() 
			+ " has won the game");
	}
	
	public void loseGame() {
		won = false; 
	}
	
	public void addShip(Ship s){
		shipsArrayList.add(s);
	}
	
	public ArrayList<Ship> getShipList() {
		return shipsArrayList; 
	}
	
}