public class Ship {
	private static int positionX; 
	private static int positionY; 
	
	public Ship(int x, int y) {
		positionX = x; 
		positionY = y; 
	}
	
	public int getX(){
		return positionX; 
	}
	
	public int getY() {
		return positionY;
	}
	
	public void setX(int pos) {
		positionX = pos; 
	}
	
	public void setY(int pos) {
		positionY = pos; 
	}
	
}